LD_LIBRARY_PATH=./LIB
export LD_LIBRARY_PATH
export LIBXCB_ALLOW_SLOPPY_LOCK=1

./jre/bin/java -jar pkbdutil.jar 2>/dev/null