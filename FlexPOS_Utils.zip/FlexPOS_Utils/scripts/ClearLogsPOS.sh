#!/bin/bash
######################################################################################################
#  NAME: ClearLogsPOS.sh
#  AUTHOR: Francisco Guevara
#
#  DESCRIPTION: Clear NCR logs files on gd90
#
#  REVISION HISTORY:
#	DATE			USER		REASON FOR CHANGE
#	2018-12-27		F0G00A4		Script Creation
#	2019-06-08		F0G00A4		Script Modification
#	2019-10-31		F0G00A4		Script Modification
#	2020-03-12		F0G00A4		Script Modification
#	2020-03-18		F0G00A4		Script Modification
######################################################################################################
#****************************************************************************************************#
#GENERAL SETTINGS
#****************************************************************************************************#
PATH_GD=/home/reg/gd90
######################################################################################################
#****************************************************************************************************#
#TERMINAL COLORS SETTINGS
#****************************************************************************************************#
######################################################################################################
NORMAL='\033[0;0m'			# NORMAL
BOLDI_CYAN='\033[1;36m'		# BOLD CYAN
BOLDI_WHITE='\033[1;37m'	# BOLD WHITE
BOLDI_BLUE='\033[1;94m'		# BOLD HIGH INTENSITY BLUE
BOLDI_RED='\033[1;91m'		# BOLD HIGH INTENSITY RED
BOLDI_GREEN='\033[1;92m'	# BOLD HIGH INTENSITY GREEN
BOLDI_YELLOW='\033[1;93m'	# BOLD HIGH INTENSITY YELLOW
######################################################################################################
#****************************************************************************************************#
#TERMINAL FUNCTIONS SETTINGS
#****************************************************************************************************#
######################################################################################################
Create_Line()
{
    local terminal_width=$(tput cols)
    local glyph="${1:-=}"

    local line=''

    for ((i=0; i<terminal_width; i++))
    do
        line+="${glyph}"
    done

	echo -e "${BOLDI_YELLOW}${line}${NORMAL}"
}
######################################################################################################
Center_Comments()
{	
	local terminal_width=$(tput cols)
	local text="${1:?}"
            
    local border_width=$(( (terminal_width - (0 * 2) - ${#text}) / 2 ))
    local border=

    for ((i=0; i<border_width; i++))
    do
        border+=" "
    done

    if (( ( terminal_width - ( 0 * 2 ) - ${#text} ) % 2 == 0 ))
    then
        local left_border=$border
        local right_border=$left_border
    else
        local left_border=$border
        local right_border="${border} "
    fi
	
	globalvar="${left_border}${text//_/ }${right_border}"
}
######################################################################################################
#****************************************************************************************************#
#GENERAL COMMANDS
#****************************************************************************************************#
######################################################################################################
echo -en "\n${BOLDI_WHITE}"
Create_Line "*"
Center_Comments "LIMPIANDO_NCR_LOGS"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
sleep 1
#****************************************************************************************************#
echo -en "\n${BOLDI_WHITE}"
echo -n "     BAJANDO INTERFAZ $(hostname) "
init 3
for dots in {1..5}
do
	echo -n "."
	sleep 1
done
echo -en "${BOLDI_RED} **INTERFAZ ABAJO**${NORMAL}"
echo -en "\n${BOLDI_WHITE}"
sleep 1
#*****************************************************************************************************
echo -e "${NORMAL}          ELIMINANDO DATOS EN: ${BOLDI_RED}${PATH_GD}/log/${NORMAL}"
rm -f ${PATH_GD}/log/*.*
sleep 1
echo -e "${NORMAL}          ELIMINANDO DATOS EN: ${BOLDI_RED}${PATH_GD}/L_JVM*.LOG${NORMAL}"
rm -f ${PATH_GD}/L_JVM*.*
sleep 1
echo -e "${NORMAL}          ELIMINANDO DATOS EN: ${BOLDI_RED}${PATH_GD}/P_REGCONF.generated.XML${NORMAL}"
rm -f ${PATH_GD}/P_REGCONF.generated.XML
sleep 1
echo -e "${NORMAL}          ELIMINANDO DATOS EN: ${BOLDI_RED}${PATH_GD}/*.REC${NORMAL}"
rm -f ${PATH_GD}/*.REC
sleep 1
#****************************************************************************************************#
echo -en "${BOLDI_WHITE}"
echo -n "     REINICIANDO INTERFAZ $(hostname) "
init 5
for dots in {1..10}
do
	echo -n "."
	sleep 1
done
echo -en "${BOLDI_GREEN} **INTERFAZ ARRIBA**${NORMAL}"
sleep 1
#****************************************************************************************************#
echo -en "\n${BOLDI_WHITE}"
Create_Line "*"
Center_Comments "LIMPIEZA_FINALIZADA"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
echo -en "\n${BOLDI_WHITE}"
sleep 1