#!/bin/bash
######################################################################################################
#  NAME: InitClearPOS.sh
#  AUTHOR: Francisco Guevara
#
#  DESCRIPTION: Initialice a clear POS
#
#  REVISION HISTORY:
#	DATE			USER		REASON FOR CHANGE
#	2019-02-14		F0G00A4		Script Creation
#	2019-06-08		F0G00A4		Script MOdification
#	2020-03-12		F0G00A4		Script MOdification
######################################################################################################
#****************************************************************************************************#
#GENERAL SETTINGS
#****************************************************************************************************#
PATH_GD=/home/reg/gd90
######################################################################################################
#****************************************************************************************************#
#TERMINAL COLORS SETTINGS
#****************************************************************************************************#
######################################################################################################
NORMAL='\033[0;0m'			# NORMAL
BOLDI_CYAN='\033[1;36m'		# BOLD CYAN
BOLDI_WHITE='\033[1;37m'	# BOLD WHITE
BOLDI_BLUE='\033[1;94m'		# BOLD HIGH INTENSITY BLUE
BOLDI_RED='\033[1;91m'		# BOLD HIGH INTENSITY RED
BOLDI_GREEN='\033[1;92m'	# BOLD HIGH INTENSITY GREEN
BOLDI_YELLOW='\033[1;93m'	# BOLD HIGH INTENSITY YELLOW
######################################################################################################
#****************************************************************************************************#
#TERMINAL FUNCTIONS SETTINGS
#****************************************************************************************************#
######################################################################################################
Create_Line()
{
    local terminal_width=$(tput cols)
    local glyph="${1:-=}"

    local line=''

    for ((i=0; i<terminal_width; i++))
    do
        line+="${glyph}"
    done

	echo -e "${BOLDI_YELLOW}${line}${BOLDI_YELLOW}"
}
######################################################################################################
Center_Comments()
{	
	local terminal_width=$(tput cols)
	local text="${1:?}"
            
    local border_width=$(( (terminal_width - (0 * 2) - ${#text}) / 2 ))
    local border=

    for ((i=0; i<border_width; i++))
    do
        border+=" "
    done

    if (( ( terminal_width - ( 0 * 2 ) - ${#text} ) % 2 == 0 ))
    then
        local left_border=$border
        local right_border=$left_border
    else
        local left_border=$border
        local right_border="${border} "
    fi
	
	globalvar="${left_border}${text//_/ }${right_border}"
}
######################################################################################################
#****************************************************************************************************#
#GENERAL COMMANDS
#****************************************************************************************************#
######################################################################################################
echo -en "\n${BOLDI_WHITE}"
Create_Line "*"
Center_Comments "INICIALIZACION_VENTAS_POS"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
#*****************************************************************************************************
echo -en "\n${BOLDI_WHITE}"
echo -n "     BAJANDO INTERFAZ $(hostname) "
init 3
for dots in {1..10}
do
	echo -n "."
	sleep 1
done
echo -en "${BOLDI_RED} **INTERFAZ ABAJO**${NORMAL}"
echo -en "\n${NORMAL}"
sleep 1
#*****************************************************************************************************
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/data/ ${NORMAL}"
rm -f ${PATH_GD}/data/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/journal/ ${NORMAL}"
rm -f ${PATH_GD}/journal/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/L_JVM*.LOG ${NORMAL}"
rm -f ${PATH_GD}/L_JVM*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/lan/ ${NORMAL}"
rm -f ${PATH_GD}/lan/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/log/ ${NORMAL}"
rm -f ${PATH_GD}/log/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/pend/ ${NORMAL}"
rm -f ${PATH_GD}/pend/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/saf/ ${NORMAL}"
rm -f ${PATH_GD}/saf/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/safe/ ${NORMAL}"
rm -f ${PATH_GD}/safe/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/safeinit/ ${NORMAL}"
rm -f ${PATH_GD}/safeinit/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/servers/ ${NORMAL}"
rm -f ${PATH_GD}/servers/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVO(S): ${BOLDI_RED}${PATH_GD}/tmp/ ${NORMAL}"
rm -f ${PATH_GD}/tmp/*.*
sleep 2
echo -e "          ELIMINANDO ARCHIVOS TEMPORALES: ${BOLDI_RED}${PATH_GD}/ ${NORMAL}"
rm -f ${PATH_GD}/*.rec
rm -f ${PATH_GD}/MNU*.*
rm -f ${PATH_GD}/J*.TXT
rm -f ${PATH_GD}/as-*.dat
rm -f ${PATH_GD}/ess.dat
rm -f ${PATH_GD}/items.dat
rm -f ${PATH_GD}/validation*.dat
rm -f ${PATH_GD}/P_*.DAT
rm -f ${PATH_GD}/S_*.DAT
rm -f ${PATH_GD}/S_*.ORG
rm -f ${PATH_GD}/*.POS
sleep 2
#*****************************************************************************************************
echo -e "          MODIFICANDO ARCHIVOS DE VENTA: ${BOLDI_RED}${PATH_GD}/GdCmos.POS${NORMAL}"
cp ${PATH_GD}/GdCmos.ORG ${PATH_GD}/GdCmos.POS
chown reg:reg -f ${PATH_GD}/GdCmos.POS
chmod 755 ${PATH_GD}/GdCmos.POS
sleep 1
#*****************************************************************************************************
echo -en "${BOLDI_WHITE}"
echo -n "     REINICIANDO INTERFAZ $(hostname) "
for dots in {1..10}
do
	echo -n "."
	sleep 1
done
echo -en "${BOLDI_GREEN} **INTERFAZ REINICIADA**${NORMAL}\n"
init 6
sleep 1
#*****************************************************************************************************
echo -en "\n${BOLDI_WHITE}"
Create_Line "*"
Center_Comments "INICIALIZACION_FINALIZADA"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
echo -en "\n${BOLDI_WHITE}"
sleep 1