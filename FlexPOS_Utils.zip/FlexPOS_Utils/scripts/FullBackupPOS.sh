#!/bin/bash
######################################################################################################
#  NAME: BackupPOS.sh
#  AUTHOR: Francisco Guevara
#
#  DESCRIPTION: Create a Backup from clear gd90
#
#  REVISION HISTORY:
#	DATE			USER		REASON FOR CHANGE
#	2018-12-24		F0G00A4		Script Creation
#	2019-06-08		F0G00A4		Script Modification
#	2019-10-31		F0G00A4		Script Modification
#	2020-03-12		F0G00A4		Script Modification
#	2020-03-18		F0G00A4		Script Modification
######################################################################################################
#****************************************************************************************************#
#GENERAL SETTINGS
#****************************************************************************************************#
######################################################################################################
PATH_GD=gd90
VERSION=$(grep 'GdPos ARS v4' ${PATH_GD}/L_J*.LOG | tail -1 | awk -F"GdPos ARS " '{print $2}' | tr '[' ' ' | tr ']' ' ' | sed -e's/  */ /g' | tr [:space:] '_' | tr '.' '_')
NAME="gd90_"$(date +"%Y%m%d")"_"${VERSION}$(hostname)".tar.gz"
######################################################################################################
#****************************************************************************************************#
#TERMINAL COLORS SETTINGS
#****************************************************************************************************#
######################################################################################################
NORMAL='\033[0;0m'			# NORMAL
BOLDI_CYAN='\033[1;36m'		# BOLD CYAN
BOLDI_WHITE='\033[1;37m'	# BOLD WHITE
BOLDI_BLUE='\033[1;94m'		# BOLD HIGH INTENSITY BLUE
BOLDI_RED='\033[1;91m'		# BOLD HIGH INTENSITY RED
BOLDI_GREEN='\033[1;92m'	# BOLD HIGH INTENSITY GREEN
BOLDI_YELLOW='\033[1;93m'	# BOLD HIGH INTENSITY YELLOW
######################################################################################################
#****************************************************************************************************#
#TERMINAL FUNCTIONS SETTINGS
#****************************************************************************************************#
######################################################################################################
Create_Line()
{
    local terminal_width=$(tput cols)
    local glyph="${1:-=}"

    local line=''

    for ((i=0; i<terminal_width; i++))
    do
        line+="${glyph}"
    done

	echo -e "${BOLDI_YELLOW}${line}${BOLDI_YELLOW}"
}
######################################################################################################
Center_Comments()
{	
	local terminal_width=$(tput cols)
	local text="${1:?}"
            
    local border_width=$(( (terminal_width - (0 * 2) - ${#text}) / 2 ))
    local border=

    for ((i=0; i<border_width; i++))
    do
        border+=" "
    done

    if (( ( terminal_width - ( 0 * 2 ) - ${#text} ) % 2 == 0 ))
    then
        local left_border=$border
        local right_border=$left_border
    else
        local left_border=$border
        local right_border="${border} "
    fi
	
	globalvar="${left_border}${text//_/ }${right_border}"
}
######################################################################################################
function Create_Backup()
{
	local _exclude=''
	local _size=''

	_exclude="$_exclude --exclude=${PATH_GD}/saf/* --exclude=${PATH_GD}/safe/* --exclude=${PATH_GD}/safeinit/* --exclude=${PATH_GD}/tmp/* "
	_exclude="$_exclude --exclude=${PATH_GD}/data/* --exclude=${PATH_GD}/lan/* --exclude=${PATH_GD}/log/* --exclude=${PATH_GD}/journal/* "
	_exclude="$_exclude --exclude=${PATH_GD}/clean/* --exclude=${PATH_GD}/diag/safe/* --exclude=${PATH_GD}/server-updates/*  --exclude=${PATH_GD}/fel/*"
	_exclude="$_exclude --exclude=${PATH_GD}/servers/* --exclude=${PATH_GD}/bmp/* --exclude=${PATH_GD}/videos/* --exclude=${PATH_GD}/firma/*"
	_exclude="$_exclude --exclude=${PATH_GD}/jrn_bkp/* "

	_exclude="$_exclude --exclude=${PATH_GD}/*.LOG --exclude=${PATH_GD}/*.log --exclude=${PATH_GD}/inq/*.DAT --exclude=${PATH_GD}/ess.dat "
	_exclude="$_exclude --exclude=${PATH_GD}/ErrorCodes.es.txt --exclude=${PATH_GD}/validation*.* --exclude=${PATH_GD}/items.dat "
	_exclude="$_exclude --exclude=${PATH_GD}/*.rec --exclude=${PATH_GD}/MNU* --exclude=${PATH_GD}/J*.TXT --exclude=${PATH_GD}/as-*.dat "
	_exclude="$_exclude --exclude=${PATH_GD}/err --exclude=${PATH_GD}/SUP --exclude=${PATH_GD}/prt --exclude=${PATH_GD}/SSD --exclude=${PATH_GD}/S_CTL* "
	_exclude="$_exclude --exclude=${PATH_GD}/test.sh --exclude=${PATH_GD}/visable.panels.properties --exclude=${PATH_GD}/javax.*properties "
	_exclude="$_exclude --exclude=${PATH_GD}/keys.dat --exclude=${PATH_GD}/libEncryptImp.so --exclude=${PATH_GD}/menuSelect --exclude=${PATH_GD}/*.zip"
	_exclude="$_exclude --exclude=${PATH_GD}/dls.properties --exclude=${PATH_GD}/el --exclude=${PATH_GD}/P_REGCONF.generated.XML --exclude=${PATH_GD}/validation_*.dat"
	
	[ -f ${NAME} ] && rm ${NAME}
	tar -czf ${NAME} ${PATH_GD} ${_exclude}
	_size="$(ls -lah ${NAME} | cut -d " " -f5)"

	echo -e "     ${BOLDI_GREEN}**RESPALDO COMPRIMIDO**${NORMAL}"
	echo -e "          ${NORMAL}PATH: ${BOLDI_CYAN}${PATH_GD}${NORMAL}"
	echo -e "          ${NORMAL}NAME: ${BOLDI_CYAN}${NAME}${NORMAL}"
	echo -e "          ${NORMAL}SIZE: ${BOLDI_CYAN}${_size}${NORMAL}"
}
######################################################################################################
#****************************************************************************************************#
#GENERAL COMMANDS
#****************************************************************************************************#
######################################################################################################
echo -en "\n${BOLDI_WHITE}"
Create_Line "*"
Center_Comments "INICIANDO_RESPALDO"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
#****************************************************************************************************#
echo -en "\n${BOLDI_WHITE}"
echo -n "     REALIZANDO COMPRESION $(hostname) "
for dots in {1..3}
do
	echo -n "."
	sleep 1
done
echo -en "${BOLDI_GREEN} **COMPRIMIENDO**${NORMAL}"
echo -en "\n${BOLDI_CYAN}"
sleep 1
Create_Backup
sleep 1
#*****************************************************************************************************
Create_Line "*"
Center_Comments "RESPALDO_FINALIZADO"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
echo -en "\n${BOLDI_WHITE}"
sleep 1