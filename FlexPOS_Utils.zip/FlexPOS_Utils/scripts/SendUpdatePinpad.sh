#!/bin/bash
######################################################################################################
#  NAME: SendUpdatePinpad.sh
#  AUTHOR: Francisco Guevara
#
#  DESCRIPTION: Update pinpad Lane5000 POS
#
#  REVISION HISTORY:
#	DATE			USER		REASON FOR CHANGE
#	2020-10-27		F0G00A4		Script Creation
######################################################################################################
#****************************************************************************************************#
#GENERAL SETTINGS
#****************************************************************************************************#
######################################################################################################
exit_code=0

#VARIABLES PATH
PATH_BASE=/home/reg
PATH_GD90="${PATH_BASE}/gd90"
######################################################################################################
#****************************************************************************************************#
#TERMINAL FUNCTIONS SETTINGS
#****************************************************************************************************#
######################################################################################################
Create_Line()
{
	local terminal_width=$(tput cols)
	local glyph="${1:-=}"

	local line=''

	for ((i=0; i<terminal_width; i++))
	do
		line+="${glyph}"
	done

	echo -e "${BOLDI_YELLOW}${line}${NORMAL}"
}
######################################################################################################
Center_Comments()
{
	local terminal_width=$(tput cols)
	local text="${1:?}"
	local border_width=$(( (terminal_width - (0 * 2) - ${#text}) / 2 ))
	local border=

	for ((i=0; i<border_width; i++))
	do
		border+=" "
	done

	if (( ( terminal_width - ( 0 * 2 ) - ${#text} ) % 2 == 0 ))
	then
		local left_border=$border
		local right_border=$left_border
	else
		local left_border=$border
		local right_border="${border} "
	fi
	
	globalvar="${left_border}${text//_/ }${right_border}"
}
######################################################################################################
function Change_ICS250
{
	local _type=$1

	cp -f ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML_ICS250 ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML 2>&1 > /dev/null
	chmod 755 ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML
	chown reg:reg ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML
}
######################################################################################################
function Change_LANE5000
{
	local _type=$1

	cp -f ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML_LANE5000 ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML 2>&1 > /dev/null
	chmod 755 ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML
	chown reg:reg ${PATH_GD90}/P_REGCONF.hierarchy.7000.Evertec-Tenders.XML
}
######################################################################################################
#****************************************************************************************************#
#START MIGRATION SETTINGS
#****************************************************************************************************#
######################################################################################################
echo -en "\n"
Create_Line "-"
Center_Comments "PROCESO ACTUALIZACION POS $(hostname) INICIADA"
echo -en "${globalvar}"
Create_Line "-"
#****************************************************************************************************#
while :
do
	echo -en "     SELECCIONE PINPAD A MODIFICAR: [1.PINPAD ICS250 2.PINPAD LANE5000] "
	read pdv_pinpad
	case ${pdv_pinpad} in
		[1-2]) break ;;
	esac
done
#****************************************************************************************************#
echo -en "     CONFIGURANDO ARCHIVO EVERTEC: P_REGCONF.hierarchy.7000.Evertec-Tenders.XML \n"
case ${pdv_pinpad} in
	1) Change_ICS250 ;;
	2) Change_LANE5000 ;;
esac
sleep 1
#****************************************************************************************************#
Create_Line "*"
Center_Comments "PROCESO ACTUALIZACION POS $(hostname) FINALIZADA"
echo -en "${globalvar}"
Create_Line "*"
echo -en "\n"
sleep 1
#****************************************************************************************************#
echo -n "     REINICIANDO POS $(hostname) "
for dots in {1..3}
do
	echo -n "."
	sleep 1
done
/sbin/init 6
echo -en "\n"