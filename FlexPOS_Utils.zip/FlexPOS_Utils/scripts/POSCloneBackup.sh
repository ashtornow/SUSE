#!/bin/bash
######################################################################################################
#  NAME: BackupPOS.sh
#  AUTHOR: Francisco Guevara
#
#  DESCRIPTION: Create a Backup from clear gd90
#
#  REVISION HISTORY:
#	DATE			USER		REASON FOR CHANGE
#	2020-07-06		F0G00A4		Script Creation
######################################################################################################
#****************************************************************************************************#
#GENERAL SETTINGS
#****************************************************************************************************#
######################################################################################################
PATH_GD=gd90
VERSION=$(grep 'GdPos ARS v4' ${PATH_GD}/L_J*.LOG | tail -1 | awk -F"GdPos ARS " '{print $2}' | tr '[' ' ' | tr ']' ' ' | sed -e's/  */ /g' | tr [:space:] '_' | tr '.' '_')
NAME="gd90_clone_"${VERSION}".tar.gz"
######################################################################################################
#****************************************************************************************************#
#TERMINAL COLORS SETTINGS
#****************************************************************************************************#
######################################################################################################
NORMAL='\033[0;0m'			# NORMAL
BOLDI_CYAN='\033[1;36m'		# BOLD CYAN
BOLDI_WHITE='\033[1;37m'	# BOLD WHITE
BOLDI_BLUE='\033[1;94m'		# BOLD HIGH INTENSITY BLUE
BOLDI_RED='\033[1;91m'		# BOLD HIGH INTENSITY RED
BOLDI_GREEN='\033[1;92m'	# BOLD HIGH INTENSITY GREEN
BOLDI_YELLOW='\033[1;93m'	# BOLD HIGH INTENSITY YELLOW
######################################################################################################
#****************************************************************************************************#
#TERMINAL FUNCTIONS SETTINGS
#****************************************************************************************************#
######################################################################################################
Create_Line()
{
    local terminal_width=$(tput cols)
    local glyph="${1:-=}"

    local line=''

    for ((i=0; i<terminal_width; i++))
    do
        line+="${glyph}"
    done

	echo -e "${BOLDI_YELLOW}${line}${BOLDI_YELLOW}"
}
######################################################################################################
Center_Comments()
{	
	local terminal_width=$(tput cols)
	local text="${1:?}"
            
    local border_width=$(( (terminal_width - (0 * 2) - ${#text}) / 2 ))
    local border=

    for ((i=0; i<border_width; i++))
    do
        border+=" "
    done

    if (( ( terminal_width - ( 0 * 2 ) - ${#text} ) % 2 == 0 ))
    then
        local left_border=$border
        local right_border=$left_border
    else
        local left_border=$border
        local right_border="${border} "
    fi
	
	globalvar="${left_border}${text//_/ }${right_border}"
}
######################################################################################################
function Create_Backup()
{
	local _exclude=''
	local _size=''

	_exclude="$_exclude --exclude=${PATH_GD}/saf --exclude=${PATH_GD}/safe --exclude=${PATH_GD}/safeinit --exclude=${PATH_GD}/tmp "
	_exclude="$_exclude --exclude=${PATH_GD}/data --exclude=${PATH_GD}/lan --exclude=${PATH_GD}/log --exclude=${PATH_GD}/journal/* "
	_exclude="$_exclude --exclude=${PATH_GD}/clean --exclude=${PATH_GD}/diag --exclude=${PATH_GD}/server-updates  --exclude=${PATH_GD}/fel/* "
	_exclude="$_exclude --exclude=${PATH_GD}/servers --exclude=${PATH_GD}/bmp --exclude=${PATH_GD}/videos --exclude=${PATH_GD}/firma/* "
	_exclude="$_exclude --exclude=${PATH_GD}/cafe --exclude=${PATH_GD}/bin --exclude=${PATH_GD}/fonts --exclude=${PATH_GD}/jpg "
	_exclude="$_exclude --exclude=${PATH_GD}/pend --exclude=${PATH_GD}/spc --exclude=${PATH_GD}/swver --exclude=${PATH_GD}/snmp "
	_exclude="$_exclude --exclude=${PATH_GD}/menu --exclude=${PATH_GD}/lib --exclude=${PATH_GD}/jars-cus --exclude=${PATH_GD}/inq/*.DAT"
	_exclude="$_exclude --exclude=${PATH_GD}/jrn_bkp/* "

	_exclude="$_exclude --exclude=${PATH_GD}/*.LOG --exclude=${PATH_GD}/*.log --exclude=${PATH_GD}/*.dat --exclude=${PATH_GD}/P_REGCONF.generated.XML "
	_exclude="$_exclude --exclude=${PATH_GD}/ErrorCodes.es.txt --exclude=${PATH_GD}/validation*.* --exclude=${PATH_GD}/MNULOG* "
	_exclude="$_exclude --exclude=${PATH_GD}/*.rec --exclude=${PATH_GD}/MNU* --exclude=${PATH_GD}/J*.TXT --exclude=${PATH_GD}/*.json "
	_exclude="$_exclude --exclude=${PATH_GD}/err --exclude=${PATH_GD}/SUP --exclude=${PATH_GD}/prt --exclude=${PATH_GD}/SSD --exclude=${PATH_GD}/S_CTL* "
	_exclude="$_exclude --exclude=${PATH_GD}/test.sh --exclude=${PATH_GD}/visable.panels.properties --exclude=${PATH_GD}/javax.*properties --exclude=${PATH_GD}/*.so "
	_exclude="$_exclude --exclude=${PATH_GD}/menuSelect --exclude=${PATH_GD}/*.zip --exclude=${PATH_GD}/7052_F2X.BAT --exclude=${PATH_GD}/AUTOPOS.CTL "
	_exclude="$_exclude --exclude=${PATH_GD}/dls.properties --exclude=${PATH_GD}/el --exclude=${PATH_GD}/TIQUETE.ce --exclude=${PATH_GD}/NOTA_DE_CREDITO.ce "
	_exclude="$_exclude --exclude=${PATH_GD}/FACTURA.ce --exclude=${PATH_GD}/7052_env.bat --exclude=${PATH_GD}/GdPos.env --exclude=${PATH_GD}/GdCmos.POS "
	_exclude="$_exclude --exclude=${PATH_GD}/jpos.xml --exclude=${PATH_GD}/52MENU.INI  --exclude=${PATH_GD}/*.BAK* --exclude=${PATH_GD}/*.bak* --exclude=${PATH_GD}/*.bkp*"
	_exclude="$_exclude --exclude=${PATH_GD}/firstLogin --exclude=${PATH_GD}/*new* --exclude=${PATH_GD}/*NEW* --exclude=${PATH_GD}/*old* --exclude=${PATH_GD}/*OLD*"
	_exclude="$_exclude --exclude=${PATH_GD}/TOTAL_*.DAT "

	[ -f ${NAME} ] && rm ${NAME}
	tar -czf ${NAME} ${PATH_GD} ${_exclude}
	_size="$(ls -lah ${NAME} | cut -d " " -f5)"

	echo -e "     ${BOLDI_GREEN}**RESPALDO COMPRIMIDO**${NORMAL}"
	echo -e "          ${NORMAL}PATH: ${BOLDI_CYAN}${PATH_GD}${NORMAL}"
	echo -e "          ${NORMAL}NAME: ${BOLDI_CYAN}${NAME}${NORMAL}"
	echo -e "          ${NORMAL}SIZE: ${BOLDI_CYAN}${_size}${NORMAL}"
}
######################################################################################################
#****************************************************************************************************#
#GENERAL COMMANDS
#****************************************************************************************************#
######################################################################################################
echo -en "\n${BOLDI_WHITE}"
Create_Line "*"
Center_Comments "INICIANDO_CLONANDO"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
#****************************************************************************************************#
echo -en "\n${BOLDI_WHITE}"
echo -n "     REALIZANDO CLONADO: $(hostname) "
sleep 1
echo -en "${BOLDI_GREEN} **CLONANDO**${NORMAL}"
echo -en "\n${BOLDI_CYAN}"
sleep 1
rm gd90_clone_v4_1_* 2>&1 > /dev/null
Create_Backup
sleep 1
#*****************************************************************************************************
Create_Line "*"
Center_Comments "CLONANDO_FINALIZADO"
echo -en "${BOLDI_YELLOW}${globalvar}${NORMAL}"
Create_Line "*"
echo -en "\n${BOLDI_WHITE}"
sleep 1